package the.domain.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import the.domain.entity.JpaBoard;

@RequiredArgsConstructor
@AllArgsConstructor
@Data

public class JpaBoardResponseDto {

	private long no;
	private String subject;
	private String content;
	private int readCount;
	private String writer;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	//생성자 파라미터에 entity 객체가 들어와서 dto에 매핑.
	public JpaBoardResponseDto(JpaBoard entity) {
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.content = entity.getContent();
		this.readCount = entity.getReadCount();
		this.writer = entity.getWriter();
		this.createdDate = entity.getCreatedDate();
		this.updatedDate = entity.getUpdatedDate();
		
	}

}
