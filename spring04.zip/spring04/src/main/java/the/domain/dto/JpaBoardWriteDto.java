package the.domain.dto;

import lombok.Data;
import the.domain.entity.JpaBoard;

@Data
public class JpaBoardWriteDto {
	private String subject;
	private String content;
	
	
	//entity 클래스로 바꾸는 메소드
	public JpaBoard toEntity() {
		JpaBoard 
		entity=JpaBoard.builder()
		.subject(subject).content(content).writer("guest").build();
		//JpaBoard entity=new JpaBoard(subject, content, "guest"); 대신,
		return entity;
	}
	

}
