package the.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Builder
@AllArgsConstructor
@EntityListeners(AuditingEntityListener.class) //auditing 활성화
@SequenceGenerator(
		name = "seq_jpaboard_generator", 
		sequenceName = "seq_jpaboard",
		initialValue = 1, allocationSize = 1)

@RequiredArgsConstructor
@Getter
@Entity

public class JpaBoard {
	
/* 이렇게 만들어도 된다.
	public JpaBoard(String subject, String content, String writer) {
		super();
		this.subject = subject;
		this.content = content;
		this.writer = writer;
	}
*/
	
	
	//제너레이터의 값을 이용하여 no에 자동세팅
	@GeneratedValue(generator = "seq_jpaboard_generator",strategy = GenerationType.SEQUENCE)
	@Id
	private long no;
	
	//컬럼 생성 // 널 아님
	@Column (nullable = false)
	private String subject;
	
	@Column (nullable = false)
	private String content;
	
	@Column
	private int readCount;
	
	@Column (nullable = false)
	private String writer;
	
	@CreatedDate
	@Column
	private LocalDateTime createdDate;
	
	@LastModifiedDate
	@Column
	private LocalDateTime updatedDate;
	
	
}
