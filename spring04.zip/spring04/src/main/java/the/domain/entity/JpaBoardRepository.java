package the.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
//dao 역할		<entity class 이름, id(PK)의 데이터값>


@Repository
public interface JpaBoardRepository extends JpaRepository<JpaBoard, Long>{
	

}
