package the.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import the.domain.dto.JpaBoardWriteDto;
import the.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	@RequestMapping("/board/list") //url주소 매핑
	public ModelAndView list() {
		System.out.println("컨트롤러 영역입니다.");
		return service.getList();
	}
	
	@GetMapping("/board/write")
	public String write() {
		return "/board/write";
	}
	

	@PostMapping("/board/write") //포스트 매핑으로 똑같은 url을 사용할수 있다.
	public String write(JpaBoardWriteDto dto) { //JpaBoardWriteDto 클래스를 사용하자.
		System.out.println(dto);
		service.save(dto);
		return "redirect:/board/list";
	}
}
