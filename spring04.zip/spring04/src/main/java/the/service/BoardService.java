package the.service;

import org.springframework.web.servlet.ModelAndView;

import the.domain.dto.JpaBoardWriteDto;

public interface BoardService {

	void save(JpaBoardWriteDto dto);

	ModelAndView getList();


}
