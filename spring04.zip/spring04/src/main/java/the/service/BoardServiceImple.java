package the.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import the.domain.dto.JpaBoardResponseDto;
import the.domain.dto.JpaBoardWriteDto;
import the.domain.entity.JpaBoard;
import the.domain.entity.JpaBoardRepository;

@Service
public class BoardServiceImple implements BoardService {
	
	@Autowired
	private JpaBoardRepository repository;
	
	@Override
	public void save(JpaBoardWriteDto dto) {
		//넘어온 데이터를 완성
		//repository는 entity 객체만 처리가능 하다.
		//dto 객체를 entity객체로 변경합니다. (안에있는 내용만 바꾼다 = toEntity 메소드)
		 JpaBoard entity = dto.toEntity();
		
		//dao(repository)
		repository.save(entity);
		
	}

	@Override
	public ModelAndView getList() {
		ModelAndView mv = new ModelAndView("/board/list");
	//	mv.setViewName("");
		//no 내림차순(desc)
		Sort sort = Sort.by(Direction.DESC, "no");
		
		

	List<JpaBoardResponseDto> list = repository.findAll(sort)
			.stream().						//콜렉션의 내용을 순서대로 나열시켜 놓아준다.
			//map(e->new JpaBoardResponseDto(e))	//람다식 표현
			map(JpaBoardResponseDto::new)			//다른 람다식
													//JpaBoardResponseDto(JpaBoard) 생성자로 리턴
			.collect(Collectors.toList());	//나열되어있는 element들을 집합으로 모아준다.
	

		mv.addObject("list", list); //request.setAttribute(name, value) 동일한 기능
		return mv;
	}
	
	

}
