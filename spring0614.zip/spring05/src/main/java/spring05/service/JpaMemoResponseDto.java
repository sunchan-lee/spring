package spring05.service;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import spring05.domain.entity.JpaMemo;


@RequiredArgsConstructor
@AllArgsConstructor
@Data
public class JpaMemoResponseDto {

	private long no;
	private String text;
	private String writer;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	
	//entity 컬럼의 데이터를 DTO컬럼으로 저장하기위한 생성자.
	public JpaMemoResponseDto(JpaMemo entity) {
		this.no = entity.getNo();
		this.text = entity.getText();
		this.writer = entity.getText();
		this.createdDate = entity.getCreatedDate();
		this.updatedDate = entity.getUpdatedDate();
	}
	
	
	
}
