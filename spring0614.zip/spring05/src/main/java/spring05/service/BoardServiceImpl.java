package spring05.service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import spring05.domain.dto.JpaMemoRequestDto;
import spring05.domain.entity.BoardRepository;
import spring05.domain.entity.JpaMemo;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	BoardRepository repository;
	
	@Override
	public void write(JpaMemoRequestDto dto) {
		System.out.println(repository);
		//DB  : DAO(repository)
		
		repository.save(dto.toEntity());
		
	//	Hibernate: select seq_memo_gen.nextval from dual
	//	Hibernate: insert into jpa_memo_test (created_date, text, updated_date, writer, no) values (?, ?, ?, ?, ?)
	}

	@Override
	public void findByAll(Model model) {
		//memo db의 모든 데이터 갖고 와서 ..페이지 로 이동.
		//갖고 간다는 개념, 모델을 통해서 갖고 간다,
		//DB정보는 Entity 객체로 반환합니다.
		int page=0;
		int size=10;
		Sort sort=Sort.by(Direction.DESC, "no");
		Pageable pageable=PageRequest.of(page, size, sort);
		//List<JpaMemo>result = repository.findAll(sort);
		Page<JpaMemo>pageObj = repository.findAll(pageable);
		
		//페이지 객체에서 게시글 내용만 추출
		List<JpaMemo>result = pageObj.getContent();
		//Entity 정보는 잘못 건드렸다가 큰일난다.
		//Entity -> Dto
		//필요없는 데이터는 안가져가도 된다.
		//페이지 이동은 모델이 알아서 해준다.
		List<JpaMemoResponseDto>list = result.stream()
						.map(JpaMemoResponseDto::new)
						.collect(Collectors.toList());
		
		model.addAttribute("toDay", LocalDate.now());
		model.addAttribute("list", list);
		
	}

	@Override
	public void findAll(int page, Model model) {
		int size=10; //한페이지에 표현할 게시글수
		System.out.println(page);
		Sort sort=Sort.by(Direction.DESC, "no");
		Pageable pageable=PageRequest.of(page, size, sort);
		
		//List<JpaMemo>result = repository.findAll(sort);
		Page<JpaMemo>pageObj = repository.findAll(pageable);
		
		System.out.println("총페이지수 : " + pageObj.getTotalPages());
		
		//페이지 객체에서 게시글 내용만 추출
		List<JpaMemo>result = pageObj.getContent();

		List<JpaMemoResponseDto>list = result.stream()
						.map(JpaMemoResponseDto::new)
						.collect(Collectors.toList());
		
		model.addAttribute("toDay", LocalDate.now());
		model.addAttribute("list", list);
		
	}
	

}
