package spring05.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import spring05.domain.dto.JpaMemoRequestDto;
import spring05.service.BoardService;

@Controller //컨트롤러 어노테이션 //컨트롤러로 사용하는 표현
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	
	
	//리스트 메뉴클릭시 /board/list 으로 넘어간다.
	@GetMapping("/board/list")
									//존재하지 않으면 0으로 세팅된 파라미터
									//문자열
									//현재 에러
	public String list(@RequestParam(defaultValue = "0") int page,Model model) {
		service.findAll(page,model);
		//String 으로 웹사이트 요청
		return "/board/list"; //templates /board.list.html 보드 아래 있는 리스트.html을 의미
	}
	
	
	//동일한 매핑에 동일한 주소는 불가능
	//다른 매핑에 동일한 주소는 가능
	//글쓰기페이지 이동
	@GetMapping("/board/write")
	public String write() {
		return "/board/write";
	}
	
	//위에 write와 다른 용도로 사용된다.
	//글쓰기 프로세스 처리
	@PostMapping("/board/write")
	public String write(JpaMemoRequestDto dto) {
		service.write(dto);		
		return "redirect:/board/write";
	}
	
	

}
