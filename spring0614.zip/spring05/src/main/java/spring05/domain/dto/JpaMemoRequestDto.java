package spring05.domain.dto;

import lombok.Data;
import spring05.domain.entity.JpaMemo;


@Data
public class JpaMemoRequestDto {
	private String text;
	private String writer;
	

	//data를 entity 객체로 세팅하기 위한 메서드
	public  JpaMemo toEntity() {
		
		return JpaMemo.builder()
				.text(text).writer(writer)
				.build();
	}

}
