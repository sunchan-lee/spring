package spring05.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//generic 표현, wrapper class로 넣어야한다.,

@Repository
public interface BoardRepository extends JpaRepository<JpaMemo, Long> {
	
}
