package test.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



//@Entity			//클래스가 entity인것을 명시하는 어노테이션
public class Test {
	
	
	//1. 사용자가 직접 지정,, 2. 자동생성되는 번호를 이용 3. 별도의 방법. (ex.Oracle - Sequence / MySQL - auto increment)
	@GeneratedValue(strategy = GenerationType.AUTO)
	//strategy = GenerationType.AUTO - 특정 DB에 게 자동으로 생성.
	//strategy = GenerationType.IDENTITY - 기본키 생성방식 DB 자체 생성방법을 사용,, mysql - auto increment
	//strategy = GenerationType.SEQUENCE - 데이터베이스의 시퀀스를 이용해서 생성(주로 오라클)
	//strategy = GenerationType.TABLE - 별도의 키를 생성해주는 채번테이블(번호를 취할 목적으로 만든 테이블))을 이용하는 방식.
	//
	
	
	
	@Id			//식별PK로 선언 - 모든 entity에는 @Id를 지정하도록 해야한다.
	long no;
	
	@Column(name ="컬럽이름",
			nullable = false, 	//null 제약조건 true, false
			unique = true,		//unique 제약조건  true, false
			insertable = true,	//insert기능여부  true, false
			updatable = false,	//수정 가능 여부  true, false
			length = 255	,	// 컬럼사이즈 default 255
			precision = 0, 		// 소수 정밀도 default 0
			scale = 0 			// 소수점 이하 자리수 default 0
			)
	String col;

}
