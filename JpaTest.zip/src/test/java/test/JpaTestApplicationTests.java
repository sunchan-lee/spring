package test;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import test.domain.entity.Exam;
import test.domain.entity.ExamRepository;

@SpringBootTest
class JpaTestApplicationTests {
	
	
	@Autowired
	ExamRepository examRepository;

	
	//@Test
	void contextLoads() {
		for(int i=1; i<20; i++) {
		Exam entity=Exam.builder()
				.subject("제목"+i)
				.content("내용"+i)
				.writer("작성자"+i)
				.build();
		examRepository.save(entity);
		
	}
		

	}
	
	//@Test
	void 모두읽어오기() {
		/*
		List<Exam> result=examRepository.findAll();
		for(Exam entity:result) {
			System.out.println(entity);	
		}
		*/
		
		examRepository.findAll().forEach(entity->{
			System.out.println(entity);
		});
		
	}
	
	//@Transactional
	//@Test
	void 데이터수정() {
		Exam entity=examRepository.findById(1L).get();
		//entity.setContent("22222222222");
		
		examRepository.save(entity);
	}
	
	//@Transactional
	///@Test
	void 데이터수정2() {
		Exam entity=examRepository.findById(1L).get();
		//entity.setContent("999999999");
		
	}
	
	@Test
	void 데이터삭제() {
		examRepository.deleteById(1L);
	}

}









