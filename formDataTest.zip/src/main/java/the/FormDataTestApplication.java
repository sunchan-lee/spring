package the;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormDataTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormDataTestApplication.class, args);
	}

}
