package the;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class TestController {
	
	@ResponseBody
	@PostMapping("/test")
	public void test(String id, String pw) {
		System.out.println("id : " + id);
		System.out.println("pw : " + pw);
	}

}
