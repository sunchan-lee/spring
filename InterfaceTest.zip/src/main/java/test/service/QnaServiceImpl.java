package test.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import test.domain.dto.QnaDto;
import test.domain.entity.QnaRepository;

@Service
public class QnaServiceImpl implements QnaService {
	
	@Autowired
	private QnaRepository qnaRepository;

	@Override
	public void insert(QnaDto dto) {
		qnaRepository.save(dto.toEntity());
	}



}
