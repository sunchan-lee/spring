package test.service;

import org.springframework.stereotype.Service;

import test.domain.dto.QnaDto;


public interface QnaService {

	void insert(QnaDto dto);


}
