package test.domain.dto;

import org.springframework.beans.factory.annotation.Autowired;

import lombok.Data;
import test.domain.entity.QnaRepository;
import test.domain.entity.QnaTest;

@Data
public class QnaDto {
	
	@Autowired
	QnaRepository qnaRepository;
	
	private long no;
	private String division;
	private String question;
	private String answer;
	
	public QnaTest toEntity() {
		return QnaTest.builder()
				.division(division)
				.question(question)
				.answer(answer)
				.build();
	}
	

}
