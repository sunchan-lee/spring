package test.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface QnaRepository extends JpaRepository<QnaTest, Long> {
	
	

}
