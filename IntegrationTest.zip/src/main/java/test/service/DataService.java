package test.service;


import test.domain.dto.RequestDto;


public interface DataService {

	void insert(RequestDto dto);

}
