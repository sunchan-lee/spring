package test.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import test.domain.dto.RequestDto;
import test.domain.entity.DataRepository;

@Service
public class DataServiceImpl implements DataService {
	
	@Autowired
	DataRepository dataRepository;

	@Override
	public void insert(RequestDto dto) {
		dataRepository.save(dto.toEntity());
		
		
	}
	
	

}
