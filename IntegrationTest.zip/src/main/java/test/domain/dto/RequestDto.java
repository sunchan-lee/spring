package test.domain.dto;

import org.springframework.beans.factory.annotation.Autowired;

import lombok.Data;
import test.domain.entity.DataEntity;
import test.domain.entity.DataRepository;

@Data
public class RequestDto {
	
	@Autowired
	DataRepository dataRepository;
	
	private String id;
	private String password;
	private String name;
	
	public DataEntity toEntity() {
		return DataEntity.builder()
				.id(id)
				.password(password)
				.name(name)
				.build();
	}
	
	

}
